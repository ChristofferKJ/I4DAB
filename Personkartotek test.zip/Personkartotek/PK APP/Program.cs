﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ApplicationLogic;

namespace PK_APP
{
    class Program
    {
        static void Main(string[] args)
        {
            PKLogicAPP gogo = new PKLogicAPP();
            gogo.TheAPP();
        }
    }
}
